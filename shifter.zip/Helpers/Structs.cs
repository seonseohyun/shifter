﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShifterUser.Helpers
{
    public struct WorkItem
    {
        public string json;
        public byte[] payload;
        public string path;
    }
}
